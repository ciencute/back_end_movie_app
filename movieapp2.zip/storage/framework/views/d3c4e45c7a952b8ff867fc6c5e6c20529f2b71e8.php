namespace <?php echo e('Database\\Factories'. $append); ?>;

use Illuminate\Database\Eloquent\Factories\Factory;
<?php if(isset($properties['remember_token'])): ?>
use Illuminate\Support\Str;
<?php endif; ?>
use <?php echo e($reflection->getName()); ?>;

class <?php echo e($reflection->getShortName()); ?>Factory extends Factory
{
    /**
    * The name of the factory's corresponding model.
    *
    * @var  string
    */
    protected $model = <?php echo e($reflection->getShortName()); ?>::class;

    /**
    * Define the model's default state.
    *
    * @return  array
    */
    public function definition(): array
    {
        return [
<?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($name); ?>' => <?php echo $property; ?>,
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ];
    }
}
<?php /**PATH C:\laragon\www\movieapp\vendor\thedoctor0\laravel-factory-generator\src/../resources/views/class-factory.blade.php ENDPATH**/ ?>