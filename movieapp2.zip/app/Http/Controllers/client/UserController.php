<?php

namespace App\Http\Controllers\client;

use App\Http\Controllers\Controller;

class UserController extends Controller
{
    public function __construct()
    {
        parent::__construct();
    }


}
