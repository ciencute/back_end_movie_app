<?php

namespace App\Http\Controllers\admin;

class ActorController
{

}
