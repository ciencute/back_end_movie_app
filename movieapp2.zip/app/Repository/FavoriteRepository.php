<?php

namespace App\Repository;

class FavoriteRepository
{
    public function create($data) {

    }
}
