# Introduction

<?php echo $description; ?>


<?php echo $introText; ?>


> Base URL

```yaml
<?php echo $baseUrl; ?>

```<?php /**PATH C:\laragon\www\movieapp\vendor\knuckleswtf\scribe\src/../resources/views//markdown/intro.blade.php ENDPATH**/ ?>