<?php

namespace App\Repository;

class UserRepository
{

}
