<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Actor\\Providers\\ActorServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Actor\\Providers\\ActorServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);